
MINAH ONLINE APP (TikTok-style)
Created for Hafizu Ssekanjako

HOW TO RUN:
1. Extract the ZIP
2. Double-click index.html
3. App opens in browser

LOGIN:
Username: admin
Password: 1234

You can upload this to any hosting:
- GitHub Pages
- Netlify
- Vercel
